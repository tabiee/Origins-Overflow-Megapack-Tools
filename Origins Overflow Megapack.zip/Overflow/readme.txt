Hello! My name is Tabee!
Thanks for checking out my bundle of origins!
-----------------------------------------------
I have also created Weeping Angel and Celestial Duo (and it's models).
Their files are not included here but they can be found on the Origins discord #datapacks channel.
Both are very complex and needed their own space!

==================================================================================================
Concerning this megapack:

=> How are there so many datapacks? Did you make all of these? How many are there?
- There are approximately 100+ origins in total.
- They are all made by me 
 . If you find someone else's work, let me know, I'll delete/credit them. I can't remember what is where unfortunately (GitHub version ignores this for now)
- 99% of these datapacks were commissioned on Fiverr by over 50 people.

=> What? Fiverr? Can you make me an origin too?
- My Fiverr is Meightaboot, although I am currently NOT active.
 . https://www.fiverr.com/meightaboot
 . I plan to (maybe) return to origins creation in summer, or whenever 1.20 comes out.
 . No promises, it depends on my interest and availability
 . I am currently studying in uni for Game Development and I might focus on Unity instead of Origins :)
- If you want to commission me, sorry not now! Please don't message me about it on Discord.
- If you commissioned me before and can see your datapack here, you may request that I remove it if you'd rather not have it shared.

=> There's something wrong with one of the datapacks, can you fix it?
- If you found a bug, no you didn't. I will not be updating anything except Weeping Angel and Celestial Duo.
- If a datapack requires another mod but doesn't state that it does, let me know.

=> Who are you and where did you even come from?
- I am a lurker in the Origins discord server. Oops :p
 . I'm too tired most of the time to be active in any discord server, or anywhere on social media really.
 . I just made a bunch of origins because they were fun, and I'm not even good at vanilla datapacks lmao
 . Frankly, I've been waiting too long to upload this stuff, I put it off for like half a year.
- You can check out my GitHub page too, it will have the unedited version of the Overflow megapack 
 . https://github.com/tabiee/Origins-Overflow-Megapack-Tools
 . That one I use actively, it includes all of my template powers and additional resources I use for datapack creation
 . Feel free to grab things from there to make origins of your own!
 . Do credit me by dropping a link to the GitHub so that more people can use my tools! I'd love to encourage creativity!
- You might also have access to the game demos me and my group at uni have been making?
 . Not entirely sure how GitHub works yet but hey if you are a programmer you can come and laugh at my terrible code


Have fun!