function tick()
	animation.bob.start()
    animation.bob.setSpeed(1.25)
	animation.bob.setLoopMode("LOOP")
end