function tick()
    animation.wiggle2.start()
    animation.wiggle2.setSpeed(1.75)
    animation.wiggle2.setLoopMode("LOOP")
    animation.wiggle2.setLoopDelay(6)
	if animation.spin2.isPlaying() then
		animation.wiggle2.stop()
	end
end
function world_render()
    animation.spin2.setSpeed(0.75)
    action_wheel.SLOT_1.setTitle("Spin!")
    action_wheel.SLOT_1.setItem("minecraft:nether_star")
    action_wheel.SLOT_1.setFunction(function()
        animation.spin2.start()
    end)
end
